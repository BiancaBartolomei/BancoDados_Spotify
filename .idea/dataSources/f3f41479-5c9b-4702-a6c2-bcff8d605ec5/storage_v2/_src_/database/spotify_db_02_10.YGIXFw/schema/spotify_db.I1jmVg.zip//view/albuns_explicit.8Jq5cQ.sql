create view albuns_explicit as
  SELECT a.album_name, art.artist_name, count(t.track_explicit) AS quant
  FROM ((((spotify_db.album a
      JOIN spotify_db.track_album ta ON (((a.album_id) :: text = (ta.album_id) :: text)))
      JOIN spotify_db.track t ON (((t.track_id) :: text = (ta.track_id) :: text)))
      JOIN spotify_db.track_artist tart ON (((tart.track_id) :: text = (t.track_id) :: text)))
      JOIN spotify_db.artist art ON (((art.artist_id) :: text = (tart.artist_id) :: text)))
  WHERE (t.track_explicit = true)
  GROUP BY a.album_name, art.artist_name
  ORDER BY (count(t.track_explicit)) DESC
  LIMIT 10;

alter table albuns_explicit
  owner to luismalta;

