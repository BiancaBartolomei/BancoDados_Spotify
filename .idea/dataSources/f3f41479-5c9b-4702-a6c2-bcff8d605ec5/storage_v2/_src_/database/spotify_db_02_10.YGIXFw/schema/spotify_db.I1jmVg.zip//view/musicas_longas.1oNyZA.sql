create view musicas_longas as
  SELECT t.track_name, a.artist_name, t.track_duration
  FROM ((spotify_db.track t
      JOIN spotify_db.track_artist ta ON (((t.track_id) :: text = (ta.track_id) :: text)))
      JOIN spotify_db.artist a ON (((a.artist_id) :: text = (ta.artist_id) :: text)))
  ORDER BY t.track_duration DESC
  LIMIT 10;

alter table musicas_longas
  owner to luismalta;

