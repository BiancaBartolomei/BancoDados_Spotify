create view top10artistasporpopularidade as
  SELECT artist.artist_name, artist.artist_popularity
  FROM spotify_db.artist
  ORDER BY artist.artist_popularity DESC
  LIMIT 10;

alter table top10artistasporpopularidade
  owner to luismalta;

