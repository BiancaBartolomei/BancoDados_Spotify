create view artistas_dancantes_view as
  SELECT DISTINCT a.artist_name, t.track_dancebility
  FROM ((spotify_db.track t
      JOIN spotify_db.track_artist q ON (((t.track_id) :: text = (q.track_id) :: text)))
      JOIN spotify_db.artist a ON (((a.artist_id) :: text = (q.artist_id) :: text)))
  ORDER BY t.track_dancebility DESC, a.artist_name
  LIMIT 10;

alter table artistas_dancantes_view
  owner to luismalta;

