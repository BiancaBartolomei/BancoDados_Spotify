create view artistas_por_genero as
  SELECT count(a.artist_name) AS quant, a.artist_genre
  FROM spotify_db.artist a
  WHERE (a.artist_genre IS NOT NULL)
  GROUP BY a.artist_genre
  ORDER BY (count(a.artist_name)) DESC;

alter table artistas_por_genero
  owner to luismalta;

