create function attartistpopularity()
  returns trigger
language plpgsql
as $$
begin
execute
'create or replace view spotify_db.top10ArtistasporPopularidade as
select  artist_name, artist_popularity
from spotify_db.artist
order by artist_popularity desc
limit 10';
return new;
end;
$$;

alter function attartistpopularity()
  owner to luismalta;

