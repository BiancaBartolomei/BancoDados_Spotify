create view musicas_instrumentais as
  SELECT t.track_name, a.artist_name, t.track_instrumentalness
  FROM ((spotify_db.track t
      JOIN spotify_db.track_artist ta ON (((t.track_id) :: text = (ta.track_id) :: text)))
      JOIN spotify_db.artist a ON (((a.artist_id) :: text = (ta.artist_id) :: text)))
  ORDER BY t.track_instrumentalness DESC
  LIMIT 10;

alter table musicas_instrumentais
  owner to luismalta;

