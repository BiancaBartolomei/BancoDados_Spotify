create function atttrackpopularity()
  returns trigger
language plpgsql
as $$
begin
execute
'create or replace view spotify_db.top10MusicasporPopularidade as
select t.track_name, a.artist_name, t.track_popularity
from spotify_db.track as t
inner join spotify_db.track_artist using (track_id)
inner join spotify_db.artist as a using(artist_id)
order by track_popularity desc
limit 10';
return new;
end;
$$;

alter function atttrackpopularity()
  owner to luismalta;

