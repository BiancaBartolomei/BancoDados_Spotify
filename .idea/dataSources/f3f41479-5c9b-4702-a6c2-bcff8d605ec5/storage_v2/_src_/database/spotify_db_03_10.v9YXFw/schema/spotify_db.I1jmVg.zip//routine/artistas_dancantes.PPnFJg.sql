create function artistas_dancantes()
  returns trigger
language plpgsql
as $$
begin
		execute 'create or replace view spotify_db.artistas_dancantes_view as' ||
		 ' select distinct a.artist_name, t.track_dancebility
			from spotify_db.track t join spotify_db.track_artist q on t.track_id = q.track_id
			join spotify_db.artist a on a.artist_id = q.artist_id
			order by t.track_dancebility desc, a.artist_name
			limit 10';
		return new;
	end;

$$;

alter function artistas_dancantes()
  owner to luismalta;

