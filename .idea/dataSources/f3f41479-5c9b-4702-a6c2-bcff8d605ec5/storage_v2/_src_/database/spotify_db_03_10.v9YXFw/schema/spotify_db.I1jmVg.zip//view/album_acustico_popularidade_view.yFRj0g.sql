create view album_acustico_popularidade_view as
  SELECT DISTINCT a.album_name, t.track_popularity
  FROM ((spotify_db.track t
      JOIN spotify_db.track_album q ON (((t.track_id) :: text = (q.track_id) :: text)))
      JOIN spotify_db.album a ON (((a.album_id) :: text = (q.album_id) :: text)))
  WHERE (t.track_acousticness > (0.5) :: double precision)
  ORDER BY t.track_popularity DESC
  LIMIT 10;

alter table album_acustico_popularidade_view
  owner to luismalta;

