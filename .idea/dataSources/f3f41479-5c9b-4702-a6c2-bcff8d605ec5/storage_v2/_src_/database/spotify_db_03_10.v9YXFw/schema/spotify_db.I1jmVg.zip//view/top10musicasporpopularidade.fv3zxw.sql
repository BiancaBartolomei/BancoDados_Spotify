create view top10musicasporpopularidade as
  SELECT t.track_name, a.artist_name, t.track_popularity
  FROM ((spotify_db.track t
      JOIN spotify_db.track_artist USING (track_id))
      JOIN spotify_db.artist a USING (artist_id))
  ORDER BY t.track_popularity DESC
  LIMIT 10;

alter table top10musicasporpopularidade
  owner to luismalta;

