create function top_musicas_mais_instrumentais_view()
  returns trigger
language plpgsql
as $$
begin
execute
'create or replace view spotify_db.musicas_instrumentais
as select t.track_name, a.artist_name, t.track_instrumentalness
from spotify_db.track t join spotify_db.track_artist ta
on t.track_id = ta.track_id join spotify_db.artist a on
a.artist_id = ta.artist_id
order by track_instrumentalness desc limit 10';
return new;
end;
$$;

alter function top_musicas_mais_instrumentais_view()
  owner to luismalta;

