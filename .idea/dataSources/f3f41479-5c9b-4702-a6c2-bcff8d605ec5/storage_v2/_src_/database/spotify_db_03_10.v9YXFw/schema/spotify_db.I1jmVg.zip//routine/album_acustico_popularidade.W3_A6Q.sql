create function album_acustico_popularidade()
  returns trigger
language plpgsql
as $$
begin
		execute 'create or replace view spotify_db.album_acustico_popularidade_view as select distinct (a.album_name), t.track_popularity
			from spotify_db.track t join spotify_db.track_album q on t.track_id = q.track_id
			join spotify_db.album a on a.album_id = q.album_id
			where t.track_acousticness > 0.5
			order by t.track_popularity desc
			limit 10';
		return new;
	end;
$$;

alter function album_acustico_popularidade()
  owner to luismalta;

