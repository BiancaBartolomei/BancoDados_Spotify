create view top10artistasporseguidores as
  SELECT artist.artist_name, artist.artist_followers
  FROM spotify_db.artist
  ORDER BY artist.artist_followers DESC
  LIMIT 10;

alter table top10artistasporseguidores
  owner to luismalta;

