create function attartistfollowers()
  returns trigger
language plpgsql
as $$
begin
execute
'create or replace view spotify_db.top10ArtistasporSeguidores as
select  artist_name, artist_followers
from spotify_db.artist
order by artist_followers desc
limit 10';
return new;
end;
$$;

alter function attartistfollowers()
  owner to luismalta;

