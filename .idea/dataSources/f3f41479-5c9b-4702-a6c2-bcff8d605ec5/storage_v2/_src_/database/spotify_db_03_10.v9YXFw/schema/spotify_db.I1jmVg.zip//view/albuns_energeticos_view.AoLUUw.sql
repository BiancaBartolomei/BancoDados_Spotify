create view albuns_energeticos_view as
  SELECT DISTINCT a.album_name, t.track_energy
  FROM ((spotify_db.album a
      JOIN spotify_db.track_album q ON (((a.album_id) :: text = (q.album_id) :: text)))
      JOIN spotify_db.track t ON (((q.track_id) :: text = (t.track_id) :: text)))
  ORDER BY t.track_energy DESC
  LIMIT 10;

alter table albuns_energeticos_view
  owner to luismalta;

