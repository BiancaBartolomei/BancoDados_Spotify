create function top_albuns_explicit_view()
  returns trigger
language plpgsql
as $$
begin
execute
'create or replace view spotify_db.albuns_explicit
as select a.album_name, art.artist_name, count(t.track_explicit) as quant
from spotify_db.album a join spotify_db.track_album ta on a.album_id = ta.album_id
join spotify_db.track t on t.track_id = ta.track_id join spotify_db.track_artist tart on
tart.track_id = t.track_id join spotify_db.artist art on art.artist_id = tart.artist_id
where t.track_explicit = True
group by (a.album_name, art.artist_name)
order by quant desc
limit 10';
return new;
end;
$$;

alter function top_albuns_explicit_view()
  owner to luismalta;

