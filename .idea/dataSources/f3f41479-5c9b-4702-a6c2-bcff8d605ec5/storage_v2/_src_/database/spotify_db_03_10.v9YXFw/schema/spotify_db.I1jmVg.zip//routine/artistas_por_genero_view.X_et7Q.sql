create function artistas_por_genero_view()
  returns trigger
language plpgsql
as $$
begin
execute
'create or replace view spotify_db.artistas_por_genero
as select count(a.artist_name) as quant, a.artist_genre
from spotify_db.artist a
where a.artist_genre is not null
group by a.artist_genre order by quant desc';
return new;
end;
$$;

alter function artistas_por_genero_view()
  owner to luismalta;

