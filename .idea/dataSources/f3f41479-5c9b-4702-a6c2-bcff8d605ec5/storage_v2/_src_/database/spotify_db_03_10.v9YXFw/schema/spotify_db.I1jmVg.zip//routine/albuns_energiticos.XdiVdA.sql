create function albuns_energiticos()
  returns trigger
language plpgsql
as $$
begin
		execute ' create or replace view spotify_db.albuns_energeticos_view as ' ||
		 'select  distinct a.album_name, t.track_energy
			from spotify_db.album a join spotify_db.track_album q on a.album_id = q.album_id
			join spotify_db.track t on q.track_id = t.track_id
			order by t.track_energy desc
			limit 10';
		return new;
	end;
$$;

alter function albuns_energiticos()
  owner to luismalta;

